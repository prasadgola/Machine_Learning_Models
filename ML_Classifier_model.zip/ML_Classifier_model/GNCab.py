# Comman for all -------------------------------------------------------


import re
import csv
import math
import numpy as np
import time

with open("Asset1.txt") as f:
    lines1 = f.readlines()

with open("Asset1.csv", "w") as file:
    for line in lines1:
        line = re.sub("[^A-Za-z0-9,.]", "", line)
        file.write(line)
        file.write("\n")

with open("Asset2.txt") as f:
    lines2 = f.readlines()

with open("Asset2.csv", "w") as file:
    for line in lines2:
        line = re.sub("[^A-Za-z0-9,.]", "", line)
        file.write(line)
        file.write("\n")


list1 = []
list2 = []


with open('Asset1.csv', 'r') as csvfile:
    Asset1data = csv.reader(csvfile)
    for line in Asset1data:
        list1.append(line)

with open('Asset2.csv', 'r') as csvfile:
    Asset2data = csv.reader(csvfile)
    for line in Asset2data:
        list2.append(line)

l1 = list1
l2 = list2


mheights = []
mweights = []
mage = []

fheights = []
fweights = []
fage = []

for i in l1:
    for j in range(len(i)-1):
        if j == 0 and i[3] == 'M':
            mheights.append(float(i[j]))
        elif j == 0 and i[3] == 'W':
            fheights.append(float(i[j]))

        elif j == 1 and i[3] == 'M':
            mweights.append(float(i[j]))
        elif j == 1 and i[3] == 'W':
            fweights.append(float(i[j]))
        elif i[3] == 'M':
            mage.append(float(i[j]))
        elif i[3] == 'W':
            fage.append(float(i[j]))


mmeanheight = sum(mheights)/len(mheights)
mmeanweight = sum(mweights)/len(mweights)
mmeanage = sum(mage)/len(mage)

fmeanheight = sum(fheights)/len(fheights)
fmeanweight = sum(fweights)/len(fweights)
fmeanage = sum(fage)/len(fage)

mstdheight = np.std(mheights)
mstdweight = np.std(mweights)
mstdage = np.std(mage)

fstdheight = np.std(fheights)
fstdweight = np.std(fweights)
fstdage = np.std(fage)



male = [[]]*len(l2)
female = [[]]*len(l2)

for i in range(len(l2)):
    for j in range(len(l2[i])):

        if j == 0:  male[i].append((1/(np.sqrt(2*np.pi)*mstdheight)) * (np.exp((-(np.float128(j)-(mmeanheight)**2))/(2*(mstdheight**2)))))
        if j == 1:  male[i].append((1/(np.sqrt(2*np.pi)*mstdweight)) * (np.exp((-(np.float128(j)-(mmeanweight)**2))/(2*(mstdweight**2)))))
        if j == 2:  male[i].append((1/(np.sqrt(2*np.pi)*mstdage)) * (np.exp((-(np.float128(j)-(mmeanage)**2))/(2*(mstdage**2)))))


        if j == 0:  female[i].append((1/(np.sqrt(2*np.pi)*fstdheight)) * (np.exp((-(np.float128(j)-(fmeanheight)**2))/(2*(fstdheight**2)))))
        if j == 1:  female[i].append((1/(np.sqrt(2*np.pi)*mstdweight)) * (np.exp((-(np.float128(j)-(mstdweight)**2))/(2*(fstdheight**2)))))
        if j == 2:  female[i].append((1/(np.sqrt(2*np.pi)*mstdage)) * (np.exp((-(np.float128(j)-(mstdage)**2))/(2*(fstdheight**2)))))

prediction = []

for i in range(len(male)):
    if np.prod(male[i]) > np.prod(female[i]):
        prediction.append("M")
    else:
        prediction.append("W")

print("Predictions = "+str(prediction))




















































