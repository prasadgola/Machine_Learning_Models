# Comman for all -------------------------------------------------------


import re
import csv
import math
import numpy as np


with open("Asset3.txt") as f:
    lines3 = f.readlines()

with open("Asset3.csv", "w") as file:
    for line in lines3:
        line = re.sub("[^A-Za-z0-9,.]", "", line)
        file.write(line)
        file.write("\n")



list3 = []


with open('Asset3.csv', 'r') as csvfile:
    Asset3data = csv.reader(csvfile)
    for line in Asset3data:
        list3.append(line)


l3 = list3

right = 0
wrong = 0


for i in range(len(l3)):
    mheights = []
    mweights = []
    mage = []

    fheights = []
    fweights = []
    fage = []

    new = l3[0:i]+l3[i+1:len(l3)]

    for p in new:
        for j in range(len(p)-1):
            if j == 0 and p[3] == 'M':
                mheights.append(float(p[j]))
            elif j == 0 and p[3] == 'W':
                fheights.append(float(p[j]))
            elif j == 1 and p[3] == 'M':
                mweights.append(float(p[j]))
            elif j == 1 and p[3] == 'W':
                fweights.append(float(p[j]))
            elif j == 2 and p[3] == 'M':
                mage.append(float(p[j]))
            elif j == 2 and p[3] == 'W':
                fage.append(float(p[j]))


    mmeanheight = sum(mheights)/len(mheights)
    mmeanweight = sum(mweights)/len(mweights)
    mmeanage = sum(mage)/len(mage)

    fmeanheight = sum(fheights)/len(fheights)
    fmeanweight = sum(fweights)/len(fweights)
    fmeanage = sum(fage)/len(fage)

    mstdheight = np.std(mheights)
    mstdweight = np.std(mweights)
    mstdage = np.std(mage)

    fstdheight = np.std(fheights)
    fstdweight = np.std(fweights)
    fstdage = np.std(fage)


    # l3[i] is a test case

    # is l3[i] is male or female ok ?


    # using those things do that or do this

    pofhbym = (1/(np.sqrt(2*np.pi)*mstdheight)) * (np.exp((-(np.float128(l3[i][0])-(mmeanheight)**2))/(2*(mstdheight**2))))
    pofwbym = (1/(np.sqrt(2*np.pi)*mstdweight)) * (np.exp((-(np.float128(l3[i][1])-(mmeanweight)**2))/(2*(mstdweight**2))))
    pofabym = (1/(np.sqrt(2*np.pi)*mstdage)) * (np.exp((-(np.float128(l3[i][2])-(mmeanage)**2))/(2*(mstdage**2))))

    pofhbyf = (1/(np.sqrt(2*np.pi)*fstdheight)) * (np.exp((-(np.float128(l3[i][0])-(fmeanheight)**2))/(2*(fstdheight**2))))
    pofwbyf = (1/(np.sqrt(2*np.pi)*fstdweight)) * (np.exp((-(np.float128(l3[i][1])-(fmeanweight)**2))/(2*(fstdweight**2))))
    pofabyf = (1/(np.sqrt(2*np.pi)*fstdage)) * (np.exp((-(np.float128(l3[i][2])-(fmeanage)**2))/(2*(fstdage**2))))


    posteriourmale = pofhbym*pofwbym*pofabym
    posteriourfemale = pofhbyf*pofwbyf*pofabyf

    if posteriourmale > posteriourfemale:
        if l3[i][3] == "M":
            right += 1
        else:
            wrong += 1
    else:
        if l3[i][3] == "W":
            right += 1
        else:
            wrong += 1







print("Accuracy is = " + str((right/len(l3)*100))+"%")





















































