Assest file are dataset files. Two types of files which are txt and csv

For question 1a and 1b, run KNNab.py file
For question 1c, run KNNc.py file
For question 1d, run KNNd.py file
For question 2a and 2b, run GNCab.py file
For question 2c, run GNCc.py file
For question 2d, run GNCd.py file