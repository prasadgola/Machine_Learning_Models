# Comman for all -------------------------------------------------------


import re
import csv
import math


with open("Asset3.txt") as f:
    lines3 = f.readlines()

with open("Asset3.csv", "w") as file:
    for line in lines3:
        line = re.sub("[^A-Za-z0-9,.]", "", line)
        file.write(line)
        file.write("\n")



list3 = []


with open('Asset3.csv', 'r') as csvfile:
    Asset3data = csv.reader(csvfile)
    for line in Asset3data:
        list3.append(line)


l3 = list3









# Distance Caluculation ---------------------------------



g = []

for i in range(len(l3)):
    distances = {}
    new = l3[0:i]+l3[i+1:len(l3)]

    for j in new:
        distances[math.sqrt( (float(j[0]) - float(l3[i][0]))**2 + (float(j[1]) - float(l3[i][1]))**2 + (float(j[2]) - float(l3[i][2]))**2 ) ] = j[3]
    
    k = []
    for i in range(1,12):
        k.append(distances[min(distances)])
        del distances[min(distances)]
    g.append(k)



# Priciting the for each K value ---------------------------------

output = []

for i in range(len(g)):
    testcase = []
    for j in range(len(g[i])):
        if j == 0:
            if g[i][j] == 'W':
                testcase.append('W')
            else:
                testcase.append('M')


        elif j == 2:
            W3,M3 = 0,0
            for p in range(len(g[i][:j])):
                if i == 'W':
                    W3 += 1
                else:
                    M3 += 1
            if W3 > M3:
                testcase.append('W')
            else:
                testcase.append('M')

        elif j == 4:
            W5,M5 = 0,0
            for p in range(len(g[i][:j])):
                if g[i][p] == 'W':
                    W5 += 1
                else:
                    M5 += 1
            if W5 > M5:
                testcase.append('W')
            else:
                testcase.append('M')

        elif j == 6:
            W7,M7 = 0,0
            for p in range(len(g[i][:j])):
                if g[i][p] == 'W':
                    W7 += 1
                else:
                    M7 += 1
            if W7 > M7:
                testcase.append('W')
            else:
                testcase.append('M')

        elif j == 8:
            W9,M9 = 0,0
            for p in range(len(g[i][:j])):
                if g[i][p] == 'W':
                    W9 += 1
                else:
                    M9 += 1
            if W9 > M9:
                testcase.append('W')
            else:
                testcase.append('M')

        elif j == 10:
            W11,M11 = 0,0
            for p in range(len(g[i][:j])):
                if g[i][p] == 'W':
                    W11 += 1
                else:
                    M11 += 1
            if W11 > M11:
                testcase.append('W')
            else:
                testcase.append('M')

    output.append(testcase)






# comparing to the old data set ---------------------------

k = [1,3,5,7,9,11]

wrong = [0]*len(k)
right = [0]*len(k)

for i in range(len(output)):
    for j in range(len(output[i])):


        if output[i][j] == l3[i][3]:
        	right[j] += 1
        else:
        	wrong[j] += 1






# Display the output --------------------------------------

for i in range(len(right)):
	print("Accuracy when k = "+str(i)+" is "+str((right[i]/len(l3))*100))





















