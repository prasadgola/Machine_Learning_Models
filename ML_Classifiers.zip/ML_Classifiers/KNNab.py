# Comman for all -------------------------------------------------------

import re
import csv
import math

with open("Asset1.txt") as f:
    lines1 = f.readlines()

with open("Asset1.csv", "w") as file:
    for line in lines1:
        line = re.sub("[^A-Za-z0-9,.]", "", line)
        file.write(line)
        file.write("\n")

with open("Asset2.txt") as f:
    lines2 = f.readlines()

with open("Asset2.csv", "w") as file:
    for line in lines2:
        line = re.sub("[^A-Za-z0-9,.]", "", line)
        file.write(line)
        file.write("\n")

with open("Asset3.txt") as f:
    lines3 = f.readlines()

with open("Asset3.csv", "w") as file:
    for line in lines3:
        line = re.sub("[^A-Za-z0-9,.]", "", line)
        file.write(line)
        file.write("\n")

list1 = []
list2 = []
list3 = []

with open('Asset1.csv', 'r') as csvfile:
    Asset1data = csv.reader(csvfile)
    for line in Asset1data:
        list1.append(line)

with open('Asset2.csv', 'r') as csvfile:
    Asset2data = csv.reader(csvfile)
    for line in Asset2data:
        list2.append(line)

with open('Asset3.csv', 'r') as csvfile:
    Asset3data = csv.reader(csvfile)
    for line in Asset3data:
        list3.append(line)

l1 = list1
l2 = list2
l3 = list3






# k value input from user -----------------------------


k = []
print("Enter the number of K-values you wanna enter")
n = int(input())
for i in range(1,n+1):
    print("Please enter the number of nearest data you wanna test for ")
    k.append(int(input()))







# Euclidean --------------------------------------------

kneartraining = []

    # len of kneartraning is same as number of testing data. 

for i in l2:
    distances = {}
    for j in l1:
        distances[math.sqrt( (float(j[0]) - float(i[0]))**2 + (float(j[1]) - float(i[1]))**2 + (float(j[2]) - float(i[2]))**2 ) ]= j[3]
    
    knears = []
    for i in range(max(k)):
        knears.append(distances[min(distances)])
        del distances[min(distances)]
    kneartraining.append(knears)


euclidean = []

for i in k:
    queue = []
    for j in range(len(kneartraining)):
        for l in range(i):
            test = kneartraining[j][:i]
            m,w = 0,0

            for y in test:
                if y == "M":
                    m+=1
                else:
                    w+=1

        if m > w:
            queue.append("M")
        else:
            queue.append("W")
    euclidean.append(queue)













# mahattan distance ---------------------------------------



kneartraining = []

for i in l2:
    distances = {}
    for j in l1:
        v1 = float(j[0]) - float(i[0])
        if v1 < 0:  v1 = v1*(-1)
        v2 = float(j[1]) - float(i[1])
        if v2 < 0:  v2 = v2*(-1)
        v3 = float(j[2]) - float(i[2])
        if v3 < 0:  v3 = v3*(-1)

        distances[ v1 + v2 + v3  ] = j[3]
    
    knears = []
    for i in range(max(k)):
        knears.append(distances[min(distances)])
        del distances[min(distances)]
    kneartraining.append(knears)

manhattan = []

for i in k:
    queue = []
    for j in range(len(kneartraining)):
        for l in range(i):
            test = kneartraining[j][:i]
            m,w = 0,0

            for y in test:
                if y == "M":
                    m+=1
                else:
                    w+=1

        if m > w:
            queue.append("M")
        else:
            queue.append("W")
    manhattan.append(queue)












#Minkowski distance --------------------------------------------

kneartraining = []

for i in l2:
    distances = {}
    for j in l1:
        l = 0
        z = len(l2[0])
        for w in range(z):
            l = l + (float(j[w]) - float(i[w]))**3
            if l < 0:   l = l*(-1)
        distances[l]= j[3]
    
    knears = []
    for i in range(max(k)):
        knears.append(distances[min(distances)])
        del distances[min(distances)]
    kneartraining.append(knears)

minkowski = []

for i in k:
    queue = []
    for j in range(len(kneartraining)):
        for l in range(i):
            test = kneartraining[j][:i]
            m,w = 0,0

            for y in test:
                if y == "M":
                    m+=1
                else:
                    w+=1

        if m > w:
            queue.append("M")
        else:
            queue.append("W")
    minkowski.append(queue)












# Display ---------------------------------------

for i in range(len(k)):
    print("For k = "+str(k[i])+", metric = manhattan"+" --> "+str(manhattan[i]))
    print("For k = "+str(k[i])+", metric = euclidean"+" --> "+str(euclidean[i]))
    print("For k = "+str(k[i])+", metric = minkowski"+" --> "+str(minkowski[i]))
    print("-------------------------------------------------------")












